webservice
==========

This is a project of my school


#### Starting project
    $ git clone git@github.com:lucascastejon/webservice.git
 
    $ cd webservice/
 
    $ python manage.py runserver
